#ifndef TCPSERV_H
#define TCPSERV_H

#include <QCoreApplication>
#include <QTcpServer>
#include <QTcpSocket>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QNetworkInterface>
#include <QDebug>
#include <QByteArray>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>
#include <QBuffer>
#include <QString>

//#include "network_subscription.h"
//#include "item.h"
//#include "map.h"
//#include "scene.h"
//#include "mainwindow.h"
#include "tcpcli.h"

//! реализовать наблюдателей бля


class Server : public QObject, public Net_subscriber
{
    Q_OBJECT

public:
    Server(Scene *scene, QObject *parent = nullptr);//MainWindow *mainWindow, 
    void SendInfo(); //! override?
    void deserializeSceneFromXML(const QString &xmlData);
    void deserializeItemFromXML(const QString &xmlData);
    QString xmlbuff ="";

public slots:
    void onReleaseMouseEvent();
    //!
    void itemInfoGetter(Item* item, int type_of_change);

    void MusicPlayGet(QString m);
    void MusicStopGet();

private slots:
    void handleNewConnection();
    void readRequest();
    QByteArray serializeSceneToXML(); //!
    //! \brief deleteSock
    QByteArray serializeItemToXML(Item *item, int type_of_change);
    QByteArray musicToXML(int type_of_change);
    void deleteSock();

    QByteArray MusicPlayToXML(QString m);
    QByteArray MusicStopToXML();

private:
    QTcpServer *m_server;
    //MainWindow *m_window; //! убрать?
    Scene *m_scene;
    //MusicPlayer *player; //Проигрыватель музыки
    QList<QTcpSocket*> m_clients;

    QString musicFilePath; //путь к файлу с музыкой
};

QString pixmapToString(const QPixmap &pixmap);

QPixmap stringToPixmap(const QString &base64String);

QString itemTypeToString(Item::ItemType t);

Item::ItemType itemTypeToEnum(const QString& t);

#endif //TCPSERV_H

#ifndef GLOBAL_H
#define GLOBAL_H

#ifndef CELL_SIZE
#define CELL_SIZE 100
#endif

#ifndef NUMBER_OF_CELLS
#define NUMBER_OF_CELLS 1000
#endif

#endif
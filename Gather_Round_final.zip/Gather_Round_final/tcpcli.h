#ifndef TCPCLI_H
#define TCPCLI_H

#include <QCoreApplication>
#include <QTcpSocket>
#include <QDebug>
#include <QHostAddress>
#include <QXmlStreamReader>
//#include "mainwindow.h"
#include "network_subscription.h"
#include "item.h"
// #include "map.h"
#include "scene.h"
#include "musicPlayer.h"

extern QString CURRENT_MUSIC;

class Client : public QObject
{
    Q_OBJECT

private:
    Scene *m_scene;
    MusicPlayer *player; //Проигрыватель музыки
    //MainWindow *m_window;

public:
    int is_start_passed = 0, pravo_imeu = 0; //! шиза :)
    //Client(const QString &subnet, quint16 port, QObject *parent = nullptr);
    Client(Scene *scene, QObject *parent = nullptr);//MainWindow *mainWindow, );
    QTcpSocket *socket;
    QByteArray serializeSceneToXML();
    QByteArray serializeItemToXML(Item *item, int type_of_change);
    QString xmlbuff ="";
    void addMusicPlayer(MusicPlayer *p) {player = p;}

public slots:
    void itemInfoGetter(Item* item, int type_of_change);

private slots:
    void sendInfo(); //override?
    void onReadyRead();
    void deserializeSceneFromXML(const QString &xmlData);
    void deserializeItemFromXML(const QString &xmlData);
    void onDisconnected();




    
};

#endif //TCPCLI_H

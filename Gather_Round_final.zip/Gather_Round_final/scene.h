#ifndef SCENE_H
#define SCENE_H

#include "item.h"

#include <QGraphicsScene>
#include <QDebug>


QT_BEGIN_NAMESPACE
class QGraphicsSceneMouseEvent;
class QMenu;
QT_END_NAMESPACE

class Scene : public QGraphicsScene
{
    Q_OBJECT

public:
    enum Mode { InsertItem, MoveItem };

    explicit Scene(QMenu *itemMenu, QObject *parent = nullptr);

    double& currScale();

    QMenu* menu(){return myItemMenu;}
    Item *item_case;

public slots:
    void setMode(Mode mode);
    void setItemType(Item::ItemType type);
    void setPixmap (QPixmap pixmap);//теперь добавляем и картинку на сцену, чтобы она создала токен с этой картинкой и вставила его
    void sandwichSlot(Item *item, int type_of_change); //Связующий слот - костыль для изменения картинки

signals:
    void itemInserted(Item *item);
    void itemSelected(QGraphicsItem *item);
    void releaseMouseEventOccurred(); //!new
    void itemInfo(Item *item, int type_of_change);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent) override;

private:
    Item::ItemType myItemType;
    QMenu *myItemMenu; //Меню для работы с объектом одинаково для всех объектов
    Mode myMode;
    QPixmap myPixmap; //картинка для вставляемого токена


    double currentScale;

   

    QPointF offset; // Смещение между позицией курсора и позицией элемента
    bool offset_changed; //Выставлено ли уже смещение
    int action_on_item = 0; //добавлен ли новый элемент?
};

#endif // SCENE_H

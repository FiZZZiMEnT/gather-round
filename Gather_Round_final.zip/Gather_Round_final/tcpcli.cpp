#include "tcpcli.h"
#include "tcpserv.h"
#include "item.h"
#include "musicPlayer.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <QGraphicsPixmapItem>
#include <QColor>
#include <QThread>

QT_BEGIN_NAMESPACE
class QPixmap;
class QGraphicsSceneContextMenuEvent;
class QMenu;
class QPolygonF;
// QT_END_NAMESPACE

QString CURRENT_MUSIC = "";

Client::Client(Scene *scene, QObject *parent)//MainWindow *mainWindow, 
    : QObject(parent), m_scene(scene), socket(new QTcpSocket(this))//, m_window(mainWindow)
    {

        connect(socket, &QTcpSocket::connected, this, &Client::sendInfo);
        connect(socket, &QTcpSocket::readyRead, this, &Client::onReadyRead);
        connect(socket, &QTcpSocket::disconnected, this, &Client::onDisconnected);
        //!
        QList<QHostAddress> addresses = QNetworkInterface::allAddresses();
        QString baseIp;
        for (const QHostAddress &address : addresses) {
            if (address.protocol() == QAbstractSocket::IPv4Protocol && !address.isLoopback()) {
                quint32 n_ip = address.toIPv4Address() & 0xFFFFFF00;
                in_addr addr;
                addr.s_addr = htonl(n_ip); // Convert host byte order to network byte order

                // Use inet_ntoa to convert in_addr to a readable string
                std::string ipString = inet_ntoa(addr);
                std::string subString = ipString.substr(0, ipString.rfind(".")+1);
                baseIp = QString::fromUtf8(subString.c_str());
                qDebug() << baseIp << "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
                break;
            }
        }

        int i=2;
        while(i<=254 and is_start_passed==0) {
            QString ip = baseIp + QString::number(i);
            //ip  = "127.0.0.1";
            qDebug() << "Проверка соединения с" << ip;
            
            socket->connectToHost(ip, 5702); 
 
            if (socket->waitForConnected(100)) {
                qDebug() << "Успешное соединение с" << ip;

                //! к спросить
                qDebug() << "Посылаем WANNAPLAY:" << ip;
                socket->write("WANNAPLAY\n");
                socket->flush();
                socket->waitForReadyRead(100);
                

                //socket->disconnectFromHost();
            } else {
                qDebug() << "Не удалось подключиться к" << ip << ":" << socket->errorString();
            }
            i++;
        }

        /*if (socket->waitForReadyRead(500000)) {
            QByteArray data = socket->readAll();
            const QString xmldata = QString::fromUtf8(data);
            qDebug() << xmldata <<" xmldata bruh";
            deserializeSceneFromXML(xmldata);
            is_start_passed = 1;
        }*/

        qDebug() << "test connection?";
        sendInfo();
        qDebug() << "info sent?";

        
        
    }


void Client::sendInfo()
{
    qDebug() << "Connected to server.";
}


void Client::onDisconnected()
{
    qDebug() << "Disconnected from server.";
}

void Client::onReadyRead()
{
    //! хуета
    if (is_start_passed == 1)
    {
        qDebug() << "FUUUUUUUUUUUUUUUUUUUUUUUUUUUUUCK";
        QByteArray data = socket->readAll();
        const QString xmlitemdata = QString::fromUtf8(data);
        //qDebug() << xmlitemdata <<" xmlitemdata bruh tcpcli.cpp onreadyread";
        deserializeItemFromXML(xmlitemdata);

    }
    else if (is_start_passed == 0)
    {
        QByteArray response = socket->readAll();
        qDebug() << "This is response:" << response.trimmed();
        if (response.trimmed() == "WANNA") {
            qDebug() << "Получен ответ 'WANNA'. Устанавливаем соединение";
            is_start_passed = 2;
            qDebug() << is_start_passed << " <- is_start_passed";
            socket->write("GET_ITEMS\n");
            socket->flush();
            
            
            
        } else {
            qDebug() << "Получен неожиданный ответ";
            socket->disconnectFromHost();
        }
    }
    else if (is_start_passed == 2){
       
        QByteArray data = socket->readAll();
        const QString xmldata = QString::fromUtf8(data);
        //qDebug() << xmldata <<" xmldata bruhhhh " << is_start_passed;
        deserializeSceneFromXML(xmldata);
        if (pravo_imeu == 1){
            is_start_passed = 1;
            qDebug() << "pravo simelos";
        }
        
    }
}

// по идее клиенту теперь не нужна
QByteArray Client::serializeSceneToXML(){
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    xmlWriter.writeStartElement("SceneItems");


    Item* circle;
    Item::ItemType type;

    // Iterate through all items in the scene
    foreach (QGraphicsItem *item, m_scene->items()) {
        if (!(item->pos().x() == 0 && item->pos().y() == 0)){
            xmlWriter.writeStartElement("Item");
            xmlWriter.writeTextElement("flag", (item->flags() & QGraphicsItem::ItemIsSelectable)? "true" : "false");

            if(item->type()==Item::Type) //Обнаружили кружок //V
            {
                circle = dynamic_cast<Item*>(item); //Достали кружок. Можем работать
                type = circle -> Item::itemType(); //Достали тип кружочка

                xmlWriter.writeTextElement("type", itemTypeToString(type));
            }

            //!
            //! делается
            //!
            xmlWriter.writeTextElement("ID", QString::number(circle->id()));
            xmlWriter.writeTextElement("Pic", pixmapToString(circle->pixmap()));
            xmlWriter.writeTextElement("PosX", QString::number(item->pos().x()));
            xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));

            // Add more properties as needed
            xmlWriter.writeEndElement(); // End Item
        }
    }

    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();

    return xmlData;
}

void Client::deserializeSceneFromXML(const QString &xmlData) {  // возможно, нужно проверять совпадение ID, если нет - то из (де)сериализации сцены убрать вообще

    if (xmlData.trimmed().startsWith("<?xml")) {
        xmlbuff = ""; 
    }
    xmlbuff += xmlData;

    if ((xmlbuff.size()-xmlbuff.lastIndexOf("</SceneItems>"))==14 || (xmlbuff.size()-xmlbuff.lastIndexOf("<SceneItems/>"))==14){
        //десерим
        pravo_imeu = 1;
        QXmlStreamReader xml(xmlbuff);
        while (!xml.atEnd()) {
            qDebug() << "Current XML token:" << xml.tokenString();
            qDebug() << "Current XML name:" << xml.name();
            qDebug() << "In deserializeSceneFromXML while";
            xml.readNext();
            
            if (xml.isStartElement() && xml.name() == "Item") {
                //qDebug() << "Current XML token:" << xml.tokenString();
                //qDebug() << "Current XML name:" << xml.name();
                QString type = "", pic = "";
                qreal posX = 0, posY = 0;
                int id=-1, currid=-1, oldid=-1;
                //!int id = 0;

                // Read attributes or child elements
                while (xml.readNextStartElement()) {
                    //qDebug() << "Current XML token:" << xml.tokenString();
                    //qDebug() << "Current XML name:" << xml.name();

                    qDebug() << "In deserializeSceneFromXML second while";
                    if (xml.name() == "type") {
                        type = xml.readElementText();
                    } else if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    } else if (xml.name() == "currID") {
                        currid = xml.readElementText().toInt();
                    } else if (xml.name() == "oldID") {
                        oldid = xml.readElementText().toInt();
                    } else if (xml.name() == "Pic") {
                        pic = xml.readElementText();
                    } else if (xml.name() == "PosX") {
                        posX = xml.readElementText().toDouble();
                    } else if (xml.name() == "PosY") {
                        posY = xml.readElementText().toDouble();
                    } else {
                        xml.skipCurrentElement();
                    }

                }
                //qDebug() << "In deserializeSceneFromXML if mid";
                // foreach (QGraphicsItem *item, m_scene->items()) {
                //     if (!(item->pos().x() == 0 && item->pos().y() == 0)){
                //         m_scene->removeItem(item);
                //     }
                // }

                Item* item;
                item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());
                item->changeID(id);
                item->changecurrID(currid);
                item->setoldID(oldid);
                qDebug() << "New Item added";
                m_scene->addItem(item);
                item->setPos(posX, posY);
                //emit itemInserted(item);
                qDebug() << "pravo imeu chages"; 
                    
            }
        }
    }    
}

/*
QByteArray Client::serializeItemToXML(Item *item, int type_of_change) {
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);
    qDebug() << "всё пизда" << type_of_change;

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    xmlWriter.writeStartElement("Items");

    qDebug() << "живы?" << type_of_change;
    switch (type_of_change) {

    case 1: // adding
        qDebug() << "всё пизда adding case" << type_of_change;
        xmlWriter.writeTextElement("Event", "1");
        // xmlWriter.writeTextElement("ID", QString::number(item->id()));
        xmlWriter.writeTextElement("Type", QString::number(item->itemType()));
        xmlWriter.writeTextElement("Pic", pixmapToString(item->pixmap()));
        xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
        xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
        break;

    case 2: // moving
        qDebug() << "всё пизда moving case" << type_of_change;
        xmlWriter.writeTextElement("Event", "2");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
        xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
        qDebug() << "всё пизда moving case end" << type_of_change;
        break;

    case 3: // movable changed
        qDebug() << "всё пизда movable case" << type_of_change;
        xmlWriter.writeTextElement("Event", "3");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;

    case 4: // selectable changed
        qDebug() << "всё пизда selectable case" << type_of_change;
        xmlWriter.writeTextElement("Event", "4");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;

/*  нет реализации видимости/невидимости
    case 5: // visionable?...
        xmlWriter.writeTextElement("Event", "5");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;


    default:
        break;
    }
    xmlWriter.writeEndElement(); // Закрываем корневой элемент
    xmlWriter.writeEndDocument();

    return xmlData;
}*/

QByteArray Client::serializeItemToXML(Item *item, int type_of_change) {
    if (item) // костыль сука
    { 
        QByteArray xmlData;
        QXmlStreamWriter xmlWriter(&xmlData);
        //qDebug() << "всё пизда" << type_of_change;
        
        xmlWriter.setAutoFormatting(true);
        xmlWriter.writeStartDocument();
        xmlWriter.writeStartElement("Items");
        
        //qDebug() << "живы?" << type_of_change;
        
        switch (type_of_change) {
        case 1: // adding
            //qDebug() << "всё пизда adding case" << type_of_change;
            xmlWriter.writeTextElement("Event", "1");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            xmlWriter.writeTextElement("currID", QString::number(item->currId()));
            xmlWriter.writeTextElement("oldID", QString::number(item->oldId()));
            xmlWriter.writeTextElement("Type", itemTypeToString(item->itemType()));
            xmlWriter.writeTextElement("Pic", pixmapToString(item->pixmap()));
            xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
            xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
            break;
            
        case 2: // moving
            //qDebug() << "всё пизда moving case" << type_of_change;
            xmlWriter.writeTextElement("Event", "2");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
            xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
            qDebug() << "всё пизда moving case end" << type_of_change;
            break;
            
        case 3: // movable changed
            //qDebug() << "movable case" << type_of_change;
            xmlWriter.writeTextElement("Event", "3");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;
            
        case 4: // selectable changed
            //qDebug() << "selectable case" << type_of_change;
            xmlWriter.writeTextElement("Event", "4");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;

        case 5: //delete
            qDebug() << "delete case" << type_of_change;
            xmlWriter.writeTextElement("Event", "5");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;
            
        default:
            break;
        }
        
        xmlWriter.writeEndElement();
        xmlWriter.writeEndDocument();
        return xmlData;
    }
    return 0;
}


/*void Client::deserializeItemFromXML(const QString &xmlData) {
    QXmlStreamReader xml(xmlData);

    while (!xml.atEnd() && !xml.hasError()) {
        xml.readNext();
        if (xml.isStartElement() && xml.name() == "Items") {
            QString type, pic;
            qreal posX = 0, posY = 0;
            int id = 0, event = 0;

            if (xml.name() == "Event") {
                event = xml.readElementText().toInt();
            } else {
                switch (event) {
                case 1: // adding
                    if (xml.name() == "Type") {
                        type = xml.readElementText();
                    } else if (xml.name() == "Pic") {
                        pic = xml.readElementText();
                    } else if (xml.name() == "PosX") {
                        posX = xml.readElementText().toDouble();
                    } else if (xml.name() == "PosY") {
                        posY = xml.readElementText().toDouble();
                    } else {
                        xml.skipCurrentElement();
                    }

                    Item* m_item;
                    m_item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());

                    m_scene->addItem(m_item);
                    m_item->setPos(posX, posY);
                    //emit itemInserted(item);
                    break;

                case 2: // moving
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    } else if (xml.name() == "PosX") {
                        posX = xml.readElementText().toDouble();
                    } else if (xml.name() == "PosY") {
                        posY = xml.readElementText().toDouble();
                    } else {
                        xml.skipCurrentElement();
                    }

                    Item* circle;

                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                circle->setPos(posX, posY);
                            }
                        }
                    }
                    break;

                case 3: // movable changed
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    }
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsMovable){
                                    circle->setFlag(QGraphicsItem::ItemIsMovable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsMovable, true);
                            }
                        }
                    }
                    break;

                case 4: // selectable changed
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    }
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsSelectable){
                                    circle->setFlag(QGraphicsItem::ItemIsSelectable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsSelectable, true);
                            }
                        }
                    }
                    break;

                    // нет реализации видимости/невидимости
                    // case 5: // visionable changed
                /*case 6:
                    m_window->player->play(CURRENT_MUSIC);

                case 7:
                    m_window->player->stop();
                default:
                    break;
                }
            }
        }
        if (xml.hasError()) {
            qDebug() << "XML Error:" << xml.errorString();
        }
    }
}*/

void Client::deserializeItemFromXML(const QString &xmlData) {
    if (xmlData.trimmed().startsWith("<?xml")) {
        xmlbuff = ""; 
    }
    xmlbuff += xmlData;

    if ((xmlbuff.size()-xmlbuff.lastIndexOf("</Items>"))==9 || (xmlbuff.size()-xmlbuff.lastIndexOf("</Music"))==13 ||
             (xmlbuff.size()-xmlbuff.lastIndexOf("<MusicStop/>"))==13){
        QXmlStreamReader xml(xmlbuff);
        while (!xml.atEnd() && !xml.hasError()) {
            //qDebug() <<"in while deserializeItemFromXML in tcpcli.cpp";
            xml.readNext();
            if (xml.isStartElement() && xml.name() == "Items") {
                QString type, pic;
                qreal posX = 0, posY = 0;
                int id = -1, event = -1, currid=-1, oldid = -1;
                //qDebug() <<"in if deserializeItemFromXML in tcpcli.cpp" << xml.name();

                //while (!(xml.isEndElement())) && xml.name() == "Items") {
                while (xml.readNextStartElement()) {
                    qDebug() << "Current element:" << xml.name() 
                            << "Type:" << xml.tokenType() 
                            << "isStartElement:" << xml.isStartElement() 
                            << "isEndElement:" << xml.isEndElement()
                            << "isCharacters:" << xml.isCharacters()
                            << "Text:" << xml.text();
                    if (xml.isStartElement()) {
                        QString elName = xml.name().toString();
                        qDebug() << "Processing element:" << elName;
                        
                        //qDebug() <<"in while2if deserializeItemFromXML in tcpcli.cpp" << elName;
                        if (elName == "Event") {
                            event = xml.readElementText().toInt();
                        } else if (elName == "Type") {
                            type = xml.readElementText();
                        } else if (elName == "Pic") {
                            pic = xml.readElementText();
                        } else if (elName == "PosX") {
                            posX = xml.readElementText().toDouble();
                        } else if (elName == "PosY") {
                            posY = xml.readElementText().toDouble();
                        } else if (elName == "ID") {
                            id = xml.readElementText().toInt();
                        } else if (elName == "currID") {
                            currid = xml.readElementText().toInt();
                        } else if (elName == "oldID") {
                            oldid = xml.readElementText().toInt();
                        } else {
                            xml.skipCurrentElement();
                        }
                    }
                    xml.readNext();
                }
                qDebug() << "B4 switch" << event;
                switch (event) {
                case 1: // adding
                    qDebug() <<"in adding deserializeItemFromXML in tcpcli.cpp";
                    Item* m_item;
                    Item* circle;
                    m_item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());
                    m_item->changeID(id);
                    m_item->changecurrID(currid);
                    m_item->setoldID(oldid);

                    m_scene->addItem(m_item);
                    m_item->setPos(posX, posY);

                    //Удаляем айтем с предыдущей картинкой

                    if (m_item->oldId()!=-1) //Если изменение проводилось хотя бы раз
                    {
                        foreach (QGraphicsItem *old_item, m_scene->items()){
                        if(old_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(old_item);
                            if(circle->id() == oldid){
                                qDebug() << "ID: " << id<< "DELETE";
                                m_scene->removeItem(circle);
                                delete circle;
                            }
                        }
                    }
                    }
                    //emit itemInserted(item);
                    break;

                case 2: // moving
                    qDebug() <<"in moving deserializeItemFromXML in tcpcli.cpp";
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                circle->setPos(posX, posY);
                            }
                        }
                    }
                    break;

                case 3: // movable changed
                    qDebug() <<"in movable deserializeItemFromXML in tcpcli.cpp!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                QGraphicsItem::GraphicsItemFlags flags = circle->flags();
                                if(flags & QGraphicsItem::ItemIsMovable){
                                    circle->setFlag(QGraphicsItem::ItemIsMovable, false);
                                    qDebug() <<"in movable deserializeItemFromXML " << circle->ItemIsMovable;
                                }
                                else
                                    circle->setFlag(QGraphicsItem::ItemIsMovable, true);
                            }
                        }
                    }
                    break;

                case 4: // selectable changed
                    qDebug() <<"in selectable deserializeItemFromXML in tcpcli.cpp";
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsSelectable){
                                    circle->setFlag(QGraphicsItem::ItemIsSelectable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsSelectable, true);
                            }
                        }
                    }
                    break;

                case 5: // delete
                    qDebug() << "in delete deserializeItemFromXML in tcpcli.cpp";
                    qDebug() <<xmlData;
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                //qDebug() << "ID: " << id<< "DELETE";
                                m_scene->removeItem(circle);
                                delete circle;
                            }
                        }
                    }
                    break;

                default:
                    qDebug() << "default switch tcpcli.cpp";
                    break;

                }
            } else if (xml.isStartElement() && xml.name() == "MusicPlay") {
                xml.readNextStartElement();
                QString musicPath;
                QString elName = xml.name().toString();
                //qDebug() << "###MUSIC START" << elName;
                if (elName == "Path") musicPath = xml.readElementText();
                //QThread* thread = QThread::create([this, musicPath](){player ->play(musicPath);});
                //thread->start();
                player ->play(musicPath);
                //qDebug() << "###MUSIC START" << musicPath;
                //xml.readNext();
            } else if (xml.isStartElement() && xml.name() == "MusicStop") {
                xml.readNextStartElement();
                //QThread* thread = QThread::create([this](){player->stop();}); // Музыка затухает в отдельном потоке
                //thread->start();
                player->stop();
                //qDebug() << "###MUSIC STOP" << xml.errorString();
                //xml.readNext();
            }
            qDebug() << "After switch";
            if (xml.hasError()) {
                qDebug() << "XML Error:" << xml.errorString();
            }
        }
    }
}


void Client::itemInfoGetter(Item* item, int type_of_change)
{
    qDebug() << "Получен сигнал o изменении позиции элемента в tcpcli.cpp > 0 x 0 <";
    QByteArray xmlitemData = serializeItemToXML(item, type_of_change);
    qDebug() << "serializetoXML passed (tcpserv.cpp)";
    
    //socket->write("DERZHI_ZABU\n");
    //socket->flush();
    socket->write(xmlitemData);
    socket->flush();


    qDebug() << "с этим всё ок (tcpserv.cpp)";
}

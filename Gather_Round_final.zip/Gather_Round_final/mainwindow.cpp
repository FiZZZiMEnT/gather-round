#include "item.h"
#include "scene.h"
#include "mainwindow.h"
#include "tcpserv.h"
#include "tcpcli.h"
#include <QtWidgets>
#include <QImage>
#include <QFileDialog>
#include <QComboBox>
#include <QSpacerItem>
#include <QThread>
#include <iostream>

MainWindow::MainWindow(Role role, const QString &roomId, QWidget *parent)
    : QMainWindow(parent), currentRole(role), roomId(roomId){
    createActions();// Привязка методов удаления, закрытия и т.д. в QAction для унификации работы со всеми меню
    createToolBox(); // Меню слева с токенами
    createMenus();

    scene = new Scene(itemMenu, this); //Построенное меню работы с объектом полностью добавляется в контекстное меню объекта
    scene->setSceneRect(QRectF(0, 0, CELL_SIZE*NUMBER_OF_CELLS, CELL_SIZE*NUMBER_OF_CELLS)); //Заменил числа на макросы
    scene->setBackgroundBrush(Qt::white); //Красим фон белым

    connect(scene, &Scene::itemInserted, this, &MainWindow::itemInserted);

    grid = new GridItem(CELL_SIZE, CELL_SIZE*NUMBER_OF_CELLS, CELL_SIZE*NUMBER_OF_CELLS); //Главная сетка //Заменил числа на макросы
    scene -> addItem(grid);
    createToolbars();

    //Разлиновываем
    QHBoxLayout *layout = new QHBoxLayout;
    layout->addWidget(toolBox);

    //Плеер
    player = new MusicPlayer();

    if (role == Master) {
        Server *server = new Server(scene); // Создаем сервер Master
        QObject::connect(scene, &Scene::releaseMouseEventOccurred, server, &Server::onReleaseMouseEvent);
        QObject::connect(scene, &Scene::itemInfo, server, &Server::itemInfoGetter);
        QObject::connect(this, &MainWindow::musicPlay, server, &Server::MusicPlayGet);
        QObject::connect(this, &MainWindow::musicStop, server, &Server::MusicStopGet);
        QObject::connect(this, &MainWindow::pictureChanged, scene, &Scene::sandwichSlot);


    } else { // Дурак (клиент)
        //qDebug() << "Suda zashli";
        Client *client = new Client(scene);
        //qDebug() << "Otsuda vishli";
        QObject::connect(scene, &Scene::itemInfo, client, &Client::itemInfoGetter);
        client -> addMusicPlayer(player);
    }

    //QVBoxLayout *mainLayout = new QVBoxLayout;
    // Добавляем информацию о роли и ID
    //setupUI(mainLayout);

    view = new QGraphicsView(scene);
    view->setDragMode(QGraphicsView::ScrollHandDrag); //Для перемещения зажимом мышки
    layout->addWidget(view);

    QWidget *widget = new QWidget;
    widget->setLayout(layout);

    setCentralWidget(widget);
    setWindowTitle(tr("Gather 'Round"));
}

void MainWindow::zoomIn()
{
    if(scene->currScale() <= 5)
    {
        std::cout << "In" << std::endl;
        scene->currScale() *= 1.25;
        view->scale(1.25, 1.25);
        std::cout << scene->currScale() << std::endl;
    }
}

void MainWindow::zoomOut()
{
    std::cout << "Out" << std::endl;
    if(scene->currScale() >= 0.2)
    {
        scene->currScale() /= 1.25;
        view->scale(0.8, 0.8);
        std::cout << scene->currScale() << std::endl;
    }
}

void MainWindow::buttonGroupClicked(QAbstractButton *button)//добавился вызов дилогового окна проводника при нажатии кнопки
{
    const QList<QAbstractButton *> buttons = buttonGroup->buttons();
    for (QAbstractButton *myButton : buttons) {
        if (myButton != button)
            button->setChecked(false);
    }
    const int id = buttonGroup->id(button);

    scene->setItemType(Item::ItemType(id));
    scene->setMode(Scene::InsertItem);

    switch (Item::ItemType(id))
    {
        case Item::Monster:
            scene -> setPixmap (QPixmap(":/images/monster.jpg"));
            break;
        case Item::Hero:
            scene -> setPixmap (QPixmap(":/images/hero.jpg"));
            break;
        case Item::Weapon:
            scene -> setPixmap (QPixmap(":/images/weapon.jpg"));
            break;
        default:
            scene -> setPixmap (QPixmap(":/images/dungeon.png"));
            break;
    }
}

void MainWindow::itemInserted(Item *item)
{
    scene->setMode(Scene::Mode(Scene::MoveItem));
    buttonGroup->button(int(item->itemType()))->setChecked(false);
}

void MainWindow::deleteItem()
{
    QList<QGraphicsItem *> selectedItems = scene->selectedItems();
    
    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        scene->item_case = dynamic_cast<Item*>(item);
        emit scene->itemInfo(scene->item_case, 5);
        scene->removeItem(item);
        delete item;
    }
}

void MainWindow::pinItem()
{
    if (scene->selectedItems().isEmpty())
        return;

    QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        item->setFlag(QGraphicsItem::ItemIsMovable, false); //нужно добавить действия с тем, что это записывается в xml и передается клиентам
        emit scene->itemInfo(dynamic_cast<Item*>(item), 3);
    }
}

void MainWindow::unpinItem()
{
    if (scene->selectedItems().isEmpty())
        return;

    QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        item->setFlag(QGraphicsItem::ItemIsMovable, true); //нужно добавить действия с тем, что это записывается в xml и передается клиентам
        emit scene->itemInfo(dynamic_cast<Item*>(item), 3);
    }
}

void MainWindow::playMusic()
{
    QString filePath = musicCombo->currentData().toString();
    player ->play(filePath);
    //QThread* thread = QThread::create([this, filePath](){player ->play(filePath);});
    //thread->start();
    // player->play(CURRENT_MUSIC);

    emit musicPlay(filePath);

    //! где-то здесь сигнал об изменении музыки (6)
    CURRENT_MUSIC = filePath;
}

void MainWindow::stopMusic()
{
    //QThread* thread = QThread::create([this](){player->stop();}); // Музыка затухает в отдельном потоке
    //thread->start();
    player->stop();
    //player->stop();

    emit musicStop();

    //! где-то здесь сигнал о выключении музыки (7)
    CURRENT_MUSIC = "";
}


//Новые методы с видимостью, но они должны распространяться только на клиентов
void MainWindow::hideItem()
{
    if (scene->selectedItems().isEmpty())
        return;

    QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        item->hide();
    }
}

void MainWindow::showItem()
{
    if (scene->selectedItems().isEmpty())
        return;

    QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        item->show();
    }
}



bool MainWindow::loadFile(const QString &fileName)
{
    QImageReader reader(fileName);
    reader.setAutoTransform(true);
    QPixmap newPixmap;
    newPixmap.load(fileName);
    if (newPixmap.isNull()) {
        QMessageBox::information(this, QGuiApplication::applicationDisplayName(),
                                 tr("Cannot load %1: %2")
                                     .arg(QDir::toNativeSeparators(fileName), reader.errorString()));
        return false;
    }

    Item::ItemType type = Item::ItemType(0);
    QPointF pos;
    QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    int oldID=0; //Запомним ID
    for (QGraphicsItem *item : qAsConst(selectedItems)) {
        type = qgraphicsitem_cast<Item *>(item)->itemType();
        pos = item->pos();
        oldID = qgraphicsitem_cast<Item *>(item)->id();
        scene->removeItem(item);
        delete item;
    }

    //this->deleteItem();
    //QList<QGraphicsItem *> selectedItems = scene->selectedItems();

    /*
        for (QGraphicsItem *item : qAsConst(selectedItems)) {
        qDebug() << "LOOOOOOOOOOOOOOOOOP";
        scene->item_case = dynamic_cast<Item*>(item);
        emit scene->itemInfo(scene->item_case, 5);
        scene->removeItem(item);
        delete item;
    }
    
    */




    Item* item = new Item(type, newPixmap, scene->menu());
    item->setoldID(oldID);
    scene->addItem(item);
    item->setPos(pos);

    emit scene->itemInfo(item, 1);

    return true;
}

static void initializeImageFileDialog(QFileDialog &dialog, QFileDialog::AcceptMode acceptMode) //метод для работы с проводником
{
    static bool firstDialog = true;
    if (firstDialog) {
        firstDialog = false;
        const QStringList picturesLocations = QStandardPaths::standardLocations(QStandardPaths::PicturesLocation);
        dialog.setDirectory(picturesLocations.isEmpty() ? QDir::currentPath() : picturesLocations.last());
    }
    QStringList mimeTypeFilters;
    const QByteArrayList supportedMimeTypes = acceptMode == QFileDialog::AcceptOpen
                                                  ? QImageReader::supportedMimeTypes() : QImageWriter::supportedMimeTypes();
    for (const QByteArray &mimeTypeName : supportedMimeTypes)
        mimeTypeFilters.append(mimeTypeName);
    mimeTypeFilters.sort();
    dialog.setMimeTypeFilters(mimeTypeFilters);
    dialog.selectMimeTypeFilter("image/jpeg");
    dialog.setAcceptMode(acceptMode);
    if (acceptMode == QFileDialog::AcceptSave)
        dialog.setDefaultSuffix("jpg");
}

void MainWindow::changePicture()
{
    QFileDialog dialog (this, tr("Add a Picture"));
        initializeImageFileDialog (dialog, QFileDialog::AcceptOpen);
        while (dialog.exec() == QDialog::Accepted && !loadFile(dialog.selectedFiles().constFirst())) {}


}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(exitAction);

    //Должно быть только у мастера
    
    if (currentRole == Master)
    {
        itemMenu = menuBar()->addMenu(tr("&Item"));
        
        itemMenu->addAction(deleteAction);
        itemMenu->addSeparator(); // Черта горизонтальная для красоты

        itemMenu->addAction(pinAction);
        itemMenu->addAction(unpinAction);

        //itemMenu->addAction(hideAction);
        //itemMenu->addAction(showAction);

        itemMenu->addAction(changeAction);
    }
}

void MainWindow::createToolbars()
{
    editToolBar = addToolBar(tr("Tools"));
    editToolBar->addAction(deleteAction);

    editToolBar->addAction(zoomInAction);
    editToolBar->addAction(zoomOutAction);


    // Должно быть только у мастера
    if (currentRole == Master)
    {
        musicToolBar = new QToolBar("Music", this);
        addToolBar(Qt::BottomToolBarArea, musicToolBar);

        // Спейсер, который сдвигает все объекты после себя вправо
        QWidget* spacer = new QWidget;
        spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
        musicToolBar ->addWidget(spacer);

        //Бокс для выбора трека
        musicCombo = new QComboBox;
        musicCombo->addItem("Tristram", "Tristram.mp3");

        musicCombo->addItem("Glasstaff Bossfight", "Glasstaff.mp3");

        musicToolBar -> addWidget(musicCombo);
        musicToolBar ->addAction(playMusicAction);
        musicToolBar ->addAction(stopMusicAction);

    }

}

void MainWindow::createToolBox()
{
    buttonGroup = new QButtonGroup(this);
    buttonGroup->setExclusive(false);
    connect(buttonGroup, QOverload<QAbstractButton *>::of(&QButtonGroup::buttonClicked),
            this, &MainWindow::buttonGroupClicked);
    
    QGridLayout *layout = new QGridLayout;
    layout->addWidget(createCellWidget(tr("Hero"), Item::Hero), 0, 0);
    layout->addWidget(createCellWidget(tr("Monster"), Item::Monster),0, 1);
    layout->addWidget(createCellWidget(tr("Weapon"), Item::Weapon), 1, 0);
    layout->addWidget(createCellWidget(tr("Map"), Item::Map), 1, 1);

    layout->setRowStretch(3, 10);
    layout->setColumnStretch(2, 10);

    QWidget *itemWidget = new QWidget;
    itemWidget->setLayout(layout);

    toolBox = new QToolBox;
    toolBox->setSizePolicy(QSizePolicy(QSizePolicy::Maximum, QSizePolicy::Ignored));
    toolBox->setMinimumWidth(itemWidget->sizeHint().width());
    toolBox->addItem(itemWidget, tr("Shapes"));
}

void MainWindow::createActions() //TODO: Найти картинки!
{
    deleteAction = new QAction(QIcon(":/images/delete.png"), tr("&Delete"), this);
    deleteAction->setShortcut(tr("Delete"));
    connect(deleteAction, &QAction::triggered, this, &MainWindow::deleteItem);

    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcuts(QKeySequence::Quit);
    connect(exitAction, &QAction::triggered, this, &QWidget::close);

    pinAction = new QAction (QIcon(":/images/pin.png"), tr("Pin"), this);
    connect(pinAction, &QAction::triggered, this, &MainWindow::pinItem);

    unpinAction = new QAction (QIcon(":/images/unpin.png"), tr("Unpin"), this);
    connect(unpinAction, &QAction::triggered, this, &MainWindow::unpinItem);

    zoomInAction = new QAction (QIcon(":/images/zoomIn.png"), tr("Zoom in"), this);
    connect(zoomInAction, &QAction::triggered, this, &MainWindow::zoomIn);

    zoomOutAction = new QAction (QIcon(":/images/zoomOut.png"), tr("Zoom out"), this);
    connect(zoomOutAction, &QAction::triggered, this, &MainWindow::zoomOut);

    playMusicAction = new QAction (QIcon(":/images/playMusic.png"), tr("Play music"), this);
    connect(playMusicAction, &QAction::triggered, this, &MainWindow::playMusic);

    stopMusicAction = new QAction (QIcon(":/images/stopMusic.png"), tr("Stop music"), this);
    connect(stopMusicAction, &QAction::triggered, this, &MainWindow::stopMusic);

    //Новые действия с видимостью

    hideAction = new QAction (tr("Hide"), this);
    connect(hideAction, &QAction::triggered, this, &MainWindow::hideItem);

    showAction = new QAction (tr("Show"), this);
    connect(showAction, &QAction::triggered, this, &MainWindow::showItem);

    changeAction = new QAction (tr("Change Picture"), this);
    connect(changeAction, &QAction::triggered, this, &MainWindow::changePicture);
}

QWidget *MainWindow::createCellWidget(const QString &text, Item::ItemType type)
{
    QPixmap pixmap(250, 250);
    pixmap.fill(Qt::transparent);

    Item item(type, pixmap, itemMenu);
    QIcon icon(item.image());

    QToolButton *button = new QToolButton;
    button->setIcon(icon);
    button->setIconSize(QSize(50, 50));
    button->setCheckable(true);
    buttonGroup->addButton(button, int(type));

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(button, 0, 0, Qt::AlignHCenter);
    layout->addWidget(new QLabel(text), 1, 0, Qt::AlignCenter);

    QWidget *widget = new QWidget;
    widget->setLayout(layout);

    return widget;
}


/* Текст накладывается. Глеб, чини

void MainWindow::setupUI(QVBoxLayout *parentLayout) {
    QLabel *roleLabel = new QLabel(this);
    QLabel *roomIdLabel = new QLabel(this);

    if (currentRole == Master) {
        roleLabel->setText("Вы создали комнату. Ваша роль: Master");
    } else {
        roleLabel->setText("Вы подключились к комнате. Ваша роль: Player");
    }

    roomIdLabel->setText("ID комнаты: " + roomId);

    parentLayout->addWidget(roleLabel);
    parentLayout->addWidget(roomIdLabel);
}

*/

#ifndef ITEM_H
#define ITEM_H
#include <QGraphicsPixmapItem>
#include <QColor>

#include "global.h"

QT_BEGIN_NAMESPACE
class QPixmap;
class QGraphicsSceneContextMenuEvent;
class QMenu;
class QPolygonF;
QT_END_NAMESPACE
class Item : public QGraphicsPixmapItem
{
public:
    enum { Type = UserType + 15 }; //Для проверки типа в дальнейшем, когда появится sendtoBack/Front
    enum ItemType { Monster, Hero, Weapon, Map}; //добавлен тип токена Map
    Item(ItemType itemType, QPixmap pixmap, QMenu *contextMenu, QGraphicsItem *parent = nullptr); //теперь есть и картинка
    ItemType itemType() const { return myItemType; }
    QPolygonF polygon() const { return myPolygon; } // Фигура для иконки в toolbox
    QPixmap pixmap() const {return myPixmap;} //возврат картинки
    QPixmap image() const; //Иконка в toolbox
    QColor color() const {return myColor;}
    int type() const override { return Type; }
    int id() const {return ID;} //возвращает поле ID. У всех токенов сквозная нумерация
    int currId() const {return currID;} //возвращает поле ID. У всех токенов сквозная нумерация
    int oldId() const {return oldID;} 

    

    //Костыли для сети
    void changeID(int new_id) {this->ID=new_id;}
    void changecurrID(int new_currid) {this->currID=new_currid;}
    void setoldID(int old) {this->oldID = old;} //После изменения картинки возвращаем айтему старый ID

protected:
    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event) override;
private:
    ItemType myItemType;
    QPolygonF myPolygon;
    QColor myColor;
    QMenu *myContextMenu;
    QPixmap myPixmap;
    static int currID; // Сквозной, общий ID
    int ID; // ID конкретного элемента
    int oldID; // ID токена с предыдущей картинкой

};
#endif // ITEM_H

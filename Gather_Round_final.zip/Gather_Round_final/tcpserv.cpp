#include "tcpserv.h"
#include "mainwindow.h"


//! реализовать наблюдателей 

Server::Server(Scene *scene, QObject *parent)//, MainWindow *mainWindow)
    : QObject(parent), m_scene(scene)//, m_window(mainWindow)
    {
        m_server = new QTcpServer(this);
        connect(m_server, &QTcpServer::newConnection, this, &Server::handleNewConnection);
        if (!m_server->listen(QHostAddress::Any, 5702)) {
            qDebug() << "Server could not start!";
        } else {
            qDebug() << "Server started on port 5702";
        }
    }

void Server::handleNewConnection()
    {
        QTcpSocket *clientSocket = m_server->nextPendingConnection();
        //!
        m_clients.append(clientSocket);
        //!
        connect(clientSocket, &QTcpSocket::readyRead, this, &Server::readRequest);
        connect(clientSocket, &QTcpSocket::disconnected, this, &Server::deleteSock);
        qDebug() << "New client connected!";
    }
 
void Server::deleteSock()
{
    QTcpSocket *client = qobject_cast<QTcpSocket* > (sender());
    if (client)
    {
        m_clients.removeAt(m_clients.indexOf(client));
    }
}

void Server::onReleaseMouseEvent() //! чекнуть что за хрень
{
    qDebug() << m_clients.size() << "Release mouse event detected";
    /*for (QTcpSocket* cli : m_clients)
    {
        qDebug() << "ANANAS";
        QByteArray xmlData = serializeSceneToXML();
        qDebug() << "ANANANAS";
        if (cli->state() == QAbstractSocket::ConnectedState) {
            qDebug() << "Socket in connected state";
            cli->write(xmlData);
        } else {
            qDebug() << "Socket not connected, cannot write";
        }
        qDebug() << "ANANANANAS";
    }*/ //! если пиздец - убрать

}

void Server::SendInfo()
{
   
}

void Server::readRequest()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    QByteArray request = clientSocket->readAll();
    qDebug() << "This is request:" << request.trimmed();
    if (request.trimmed() == "WANNAPLAY") {
        qDebug() << "Connection with code word";
        //QByteArray xmlData = serializeSceneToXML(); //! depricated
        clientSocket->write("WANNA");
        //?clientSocket->disconnectFromHost();
    }
    else if (request.trimmed() == "GET_ITEMS") {
        qDebug() << "Get_items command";
        QByteArray xmlData = serializeSceneToXML(); //! depricated
        clientSocket->write(xmlData);
        clientSocket->flush();
        //?clientSocket->disconnectFromHost();
    }
    else if (request.trimmed() == "DERZHI_ZABU")
    {
        qDebug() << "DERZHI_ZABU command";
        
    }
    else
    {
        qDebug() << "after DERZHI_ZABU command";
        const QString xmlitemdata = QString::fromUtf8(request);
        qDebug() << "after DERZHI_ZABU command data:" << xmlitemdata;
        qDebug() << xmlitemdata <<" xmldata bruh";
        deserializeItemFromXML(xmlitemdata); 
    }
}

QByteArray Server::serializeSceneToXML()
    {
        qDebug() << "в serializeSceneToXML working";
        QByteArray xmlData;
        QXmlStreamWriter xmlWriter(&xmlData);
        
        xmlWriter.setAutoFormatting(true);
        xmlWriter.writeStartDocument();
        xmlWriter.writeStartElement("SceneItems");

        Item* circle;
        Item::ItemType type;

        foreach (QGraphicsItem *item, m_scene->items()) { //QGraphicsItem
            if (!(item->pos().x() == 0 && item->pos().y() == 0)){
                xmlWriter.writeStartElement("Item");
                xmlWriter.writeTextElement("flag", (item->flags() & QGraphicsItem::ItemIsSelectable)? "true" : "false");

                /*if(item->type()==Item::Type) //Обнаружили кружок //V
                {
                    
                }*/

                circle = dynamic_cast<Item*>(item); //Достали кружок. Можем работать
                type = circle -> Item::itemType(); //Достали тип кружочка

                xmlWriter.writeTextElement("type", itemTypeToString(type));
                xmlWriter.writeTextElement("ID", QString::number(circle->id()));
                xmlWriter.writeTextElement("currID", QString::number(circle->currId()));
                xmlWriter.writeTextElement("Pic", pixmapToString(circle->pixmap()));
                xmlWriter.writeTextElement("PosX", QString::number(item->pos().x()));
                xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
                    
                xmlWriter.writeEndElement(); // End Item
            }
        }

        xmlWriter.writeEndElement();
        xmlWriter.writeEndDocument();
        //qDebug() << xmlData;
        return xmlData;
    }

void Server::deserializeSceneFromXML(const QString &xmlData) {  // возможно, нужно проверять совпадение ID, если нет - то из (де)сериализации сцены убрать вообще
    QXmlStreamReader xml(xmlData);
    
    while (!xml.atEnd() && !xml.hasError()) {
        xml.readNext();
        if (xml.isStartElement() && xml.name() == "Item") {
            QString type, pic;
            qreal posX = 0, posY = 0;
            // int id = 0;

            // Read attributes or child elements
            while (xml.readNextStartElement()) {
                if (xml.name() == "type") {
                    type = xml.readElementText();
                // } else if (xml.name() == "ID") {
                //     id = xml.readElementText().toInt();
                } else if (xml.name() == "Pic") {
                    pic = xml.readElementText();
                } else if (xml.name() == "PosX") {
                    posX = xml.readElementText().toDouble();
                } else if (xml.name() == "PosY") {
                    posY = xml.readElementText().toDouble();
                } else {
                    xml.skipCurrentElement();
                }

            }
 
            // foreach (QGraphicsItem *item, m_scene->items()) {
            //     if (!(item->pos().x() == 0 && item->pos().y() == 0)){
            //         m_scene->removeItem(item);
            //     }
            // }
            

            Item* item;
            item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());

            m_scene->addItem(item);
            item->setPos(posX, posY);
            //emit itemInserted(item);


            if (xml.hasError()) {
                qDebug() << "XML Error:" << xml.errorString();
            }
        }
    }
}

/*QByteArray Server::serializeItemToXML(Item *item, int type_of_change) {
    qDebug() << "check1 (serializeItemToXML())";
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);

    if (item) {
        qDebug() << "This is item:" << item;
    } else {
        qDebug() << "Item is null";
    }
    if (!item) {
        qDebug() << "Item address:" << (void*)item;
        qDebug() << "Error: Null item pointer in serializeItemToXML";
        return QByteArray();
    }

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    xmlWriter.writeStartElement("Items"); // Добавляем корневой элемент

    qDebug() << "check2 (serializeItemToXML())";
    switch (type_of_change) {
    case 1: // adding
        qDebug() << "checkadding (serializeItemToXML())";
        xmlWriter.writeTextElement("Event", "1");
        qDebug() << "checkadding (serializeItemToXML())";
        // xmlWriter.writeTextElement("ID", QString::number(item->id()));
        xmlWriter.writeTextElement("Type", QString::number(item->itemType()));
        qDebug() << "checkadding (serializeItemToXML())";
        xmlWriter.writeTextElement("Pic", pixmapToString(item->pixmap()));
        qDebug() << "checkadding (serializeItemToXML())";
        xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
        xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
        qDebug() << "checkadding (serializeItemToXML())";
        break;


    case 2: // moving
        qDebug() << "checkmoving (serializeItemToXML())";
        xmlWriter.writeTextElement("Event", "2");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
        xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
        break;

    case 3: // movable changed
        qDebug() << "checkmovablechanged (serializeItemToXML())";
        xmlWriter.writeTextElement("Event", "3");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;

    case 4: // selectable changed
        qDebug() << "checkselectablechanged (serializeItemToXML())";
        xmlWriter.writeTextElement("Event", "4");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;

/*  нет реализации видимости/невидимости
    case 5: // visionable?...
        xmlWriter.writeTextElement("Event", "5");
        xmlWriter.writeTextElement("ID", QString::number(item->id()));
        break;


    default:
        qDebug() << "checkdefault (serializeItemToXML())";
        break;
    }
    qDebug() << "check3 (serializeItemToXML())";
    xmlWriter.writeEndElement(); // Закрываем корневой элемент
    xmlWriter.writeEndDocument();

    return xmlData;
}*/

QByteArray Server::serializeItemToXML(Item *item, int type_of_change) {
    if (item) 
    {
        QByteArray xmlData;
        QXmlStreamWriter xmlWriter(&xmlData);
        
        xmlWriter.setAutoFormatting(true);
        xmlWriter.writeStartDocument();
        xmlWriter.writeStartElement("Items");
        
        qDebug() << "живы?" << type_of_change;
    
        switch (type_of_change) {
        case 1: // adding
            qDebug() << "adding case" << type_of_change;
            xmlWriter.writeTextElement("Event", "1");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            xmlWriter.writeTextElement("currID", QString::number(item->currId()));
            xmlWriter.writeTextElement("oldID", QString::number(item->oldId()));
            xmlWriter.writeTextElement("Type", itemTypeToString(item->itemType()));
            xmlWriter.writeTextElement("Pic", pixmapToString(item->pixmap()));
            xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
            xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
            break;
            
        case 2: // moving
            qDebug() << "moving case" << type_of_change;
            xmlWriter.writeTextElement("Event", "2");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            xmlWriter.writeTextElement("PosX", QString::number(item->pos().x())); // Maybe scene position? - No.
            qDebug() << "this is NOT xmlWritererror";
            xmlWriter.writeTextElement("PosY", QString::number(item->pos().y()));
            qDebug() << "moving case end" << type_of_change;
            break;
            
        case 3: // movable changed
            qDebug() << "movable case" << type_of_change;
            xmlWriter.writeTextElement("Event", "3");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;
            
        case 4: // selectable changed
            qDebug() << "selectable case" << type_of_change;
            xmlWriter.writeTextElement("Event", "4");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;
        case 5: //delete 
            qDebug() << "delete case" << type_of_change;
            xmlWriter.writeTextElement("Event", "5");
            xmlWriter.writeTextElement("ID", QString::number(item->id()));
            break;
            
        default:
            break;
        }
    
    
    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();
    //qDebug() << xmlData;
    return xmlData;
    }
    return 0;
}


QByteArray Server::musicToXML(int type_of_change) {
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();

    switch (type_of_change) {
    case 6: // play music
        xmlWriter.writeTextElement("Event", "6");
        xmlWriter.writeTextElement("Path", CURRENT_MUSIC);
        // xmlWriter.writeTextElement("Path", m_window->player->);
        break;

    case 7: // stop
        xmlWriter.writeTextElement("Event", "7");
        break;

    default:
        break;
    }

    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();

    return xmlData;
}

QByteArray Server::MusicPlayToXML(QString m) {
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();

    xmlWriter.writeStartElement("MusicPlay");
    xmlWriter.writeTextElement("Path", m);

    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();

    qDebug() << xmlData;

    return xmlData;
}

void Server::MusicPlayGet(QString m) {
    QByteArray xmlMusicData = MusicPlayToXML(m);
    qDebug() << "serializetoXML passed (tcpserv.cpp)";
    
    for (QTcpSocket* client_sock : m_clients)
    {
        qDebug() << "в for (tcpserv.cpp) music play";
        if (client_sock && client_sock->isValid())
        {
            qDebug() << "держи, бро";
            client_sock->write(xmlMusicData);
        }
    }
    qDebug() << "с этим всё ок (tcpserv.cpp) music play";
}

QByteArray Server::MusicStopToXML() {
    QByteArray xmlData;
    QXmlStreamWriter xmlWriter(&xmlData);

    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();

    xmlWriter.writeStartElement("MusicStop");

    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();

    return xmlData;
}

void Server::MusicStopGet() {
    QByteArray xmlMusicData = MusicStopToXML();
    qDebug() << "serializetoXML passed (tcpserv.cpp)";
    
    for (QTcpSocket* client_sock : m_clients)
    {
        qDebug() << "в for (tcpserv.cpp) music stop";
        if (client_sock && client_sock->isValid())
        {
            qDebug() << "держи, бро";
            client_sock->write(xmlMusicData);
        }
    }
    qDebug() << "с этим всё ок (tcpserv.cpp) music stop";
}

/*void Server::deserializeItemFromXML(const QString &xmlData) {
    QXmlStreamReader xml(xmlData);
    qDebug() << "In deserializeItemFromXML Щ_щ";
    while (!xml.atEnd() && !xml.hasError()) {
        qDebug() << "In deserializeItemFromXML Щ_щ in while";
        xml.readNext();
        qDebug() << xml.name() << "XML NAME!!!";
        if (xml.isStartElement() && xml.name() == "Items") {
            qDebug() << "In deserializeItemFromXML Щ_щ in if!!!!";
            QString type, pic;
            qreal posX = 0, posY = 0;
            int id, event = 0;

            if (xml.name() == "Event") {
                event = xml.readElementText().toInt();
                qDebug() << "EVENT NUM" << event;
            } else {
                switch (event) {
                case 1: // adding
                    qDebug() << "Щ_щ adding";
                    if (xml.name() == "Type") {
                        type = xml.readElementText();
                    } else if (xml.name() == "Pic") {
                        pic = xml.readElementText();
                    } else if (xml.name() == "PosX") {
                        posX = xml.readElementText().toDouble();
                    } else if (xml.name() == "PosY") {
                        posY = xml.readElementText().toDouble();
                    } else {
                        xml.skipCurrentElement();
                    }

                    Item* m_item;
                    m_item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());

                    m_scene->addItem(m_item);
                    m_item->setPos(posX, posY);
                    //emit itemInserted(item);
                    break;

                case 2: // moving
                    qDebug() << "Щ_щ moving";
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    } else if (xml.name() == "PosX") {
                        posX = xml.readElementText().toDouble();
                    } else if (xml.name() == "PosY") {
                        posY = xml.readElementText().toDouble();
                    } else {
                        xml.skipCurrentElement();
                    }

                    Item* circle;

                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                circle->setPos(posX, posY);
                            }
                        }
                    }
                    break;

                case 3: // movable changed
                    qDebug() << "Щ_щ movable";
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    }
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsMovable){
                                    circle->setFlag(QGraphicsItem::ItemIsMovable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsMovable, true);
                            }
                        }
                    }
                    break;

                case 4: // selectable changed
                    qDebug() << "Щ_щ selectavle";
                    if (xml.name() == "ID") {
                        id = xml.readElementText().toInt();
                    }
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsSelectable){
                                    circle->setFlag(QGraphicsItem::ItemIsSelectable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsSelectable, true);
                            }
                        }
                    }
                    break;

                // нет реализации видимости/невидимости
                // case 5: // visionable changed

                // а это серверу не надо по идее
                // case 6:
                //     m_window->player->play(CURRENT_MUSIC);

                // case 7:
                //     m_window->player->stop();


                default:
                    qDebug() << "Щ_щ default какого хуя";
                    break;
                }
            }
        }
        if (xml.hasError()) {
            qDebug() << "XML Error:" << xml.errorString();
        }
    }
}*/

void Server::deserializeItemFromXML(const QString &xmlData) {
    if (xmlData.trimmed().startsWith("<?xml")) {
        xmlbuff = ""; 
    }
    xmlbuff += xmlData;

    if ((xmlbuff.size()-xmlbuff.lastIndexOf("</Items>"))==9) {
        QXmlStreamReader xml(xmlbuff);
        while (!xml.atEnd() && !xml.hasError()) {
            xml.readNext();
            if (xml.isStartElement() && xml.name() == "Items") {
                QString type, pic;
                qreal posX = 0, posY = 0;
                int id = -1, event = -1, currid=-1, oldid=-1;

                //while (!(xml.isEndElement()) && xml.name() == "Items") {
                while (xml.readNextStartElement()) {
                    if (xml.isStartElement()) {
                        QString elName = xml.name().toString();
                        if (elName == "Event") {
                            event = xml.readElementText().toInt();
                        } else if (elName == "Type") {
                            type = xml.readElementText();
                        } else if (elName == "Pic") {
                            pic = xml.readElementText();
                        } else if (elName == "PosX") {
                            posX = xml.readElementText().toDouble();
                        } else if (elName == "PosY") {
                            posY = xml.readElementText().toDouble();
                        } else if (elName == "ID") {
                            id = xml.readElementText().toInt();
                        } else if (elName == "currID") {
                            currid = xml.readElementText().toInt();
                        } else if (elName == "oldID") {
                            oldid = xml.readElementText().toInt();
                        } else {
                            xml.skipCurrentElement();
                        }
                    }
                    xml.readNext();
                }

                switch (event) {
                case 1: // adding
                    Item* m_item;
                    Item* circle;
                    m_item = new Item(itemTypeToEnum(type), stringToPixmap(pic), m_scene->menu());
                    m_item->changeID(id);
                    m_item->changecurrID(currid);
                    m_item->setoldID(oldid);

                    m_scene->addItem(m_item);
                    m_item->setPos(posX, posY);

                    //Удаляем айтем с предыдущей картинкой

                    if (m_item->oldId()!=-1) //Если изменение проводилось хотя бы раз
                    {
                        foreach (QGraphicsItem *old_item, m_scene->items()){
                        if(old_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(old_item);
                            if(circle->id() == oldid){
                                qDebug() << "ID: " << id<< "DELETE";
                                m_scene->removeItem(circle);
                                delete circle;
                            }
                        }
                    }
                    }
                    //emit itemInserted(item);
                    break;

                case 2: // moving
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                circle->setPos(posX, posY);
                            }
                        }
                    }
                    break;

                case 3: // movable changed
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsMovable){
                                    circle->setFlag(QGraphicsItem::ItemIsMovable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsMovable, true);
                            }
                        }
                    }
                    break;

                case 4: // selectable changed
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                if(circle->ItemIsSelectable){
                                    circle->setFlag(QGraphicsItem::ItemIsSelectable, false);
                                }
                                circle->setFlag(QGraphicsItem::ItemIsSelectable, true);
                            }
                        }
                    }
                    break;

                case 5: //!
                    foreach (QGraphicsItem *m_item, m_scene->items()){
                        if(m_item->type()==Item::Type)
                        {
                            circle = dynamic_cast<Item*>(m_item);
                            if(circle->id() == id){
                                m_scene->removeItem(circle);
                                delete circle;
                            }
                        }
                    }

                    break;

                default:
                    break;

                }
            }
            if (xml.hasError()) {
                qDebug() << "XML Error:" << xml.errorString();
            }
        }
    }
}



QString pixmapToString(const QPixmap &pixmap) {
    // Конвертируем QPixmap в QImage
    QImage image = pixmap.toImage();

    // Сохраняем QImage в QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    image.save(&buffer, "PNG"); // Вы можете выбрать другой формат, если необходимо

    // Кодируем QByteArray в Base64
    QString base64String = QString(byteArray.toBase64());

    return base64String;
}

QPixmap stringToPixmap(const QString &base64String) {
    // Декодируем строку Base64 в QByteArray
    QByteArray byteArray = QByteArray::fromBase64(base64String.toUtf8());

    // Создаем QImage из QByteArray
    QImage image;
    image.loadFromData(byteArray, "PNG"); // Убедитесь, что формат соответствует тому, что вы использовали при сохранении

    // Преобразуем QImage в QPixmap
    QPixmap pixmap = QPixmap::fromImage(image);

    return pixmap;
}

QString itemTypeToString(Item::ItemType t) {
    switch (t) {
    case Item::ItemType::Hero:    return "Hero";
    case Item::ItemType::Monster:  return "Monster";
    case Item::ItemType::Weapon:   return "Weapon";
    case Item::ItemType::Map: return "Map";
    default:     return "Unknown"; // Для обработки несуществующих значений
    }
}

Item::ItemType itemTypeToEnum(const QString& t) {
    if (t == "Hero") {
        return Item::ItemType::Hero;
    } else if (t == "Monster") {
        return Item::ItemType::Monster;
    } else if (t == "Weapon") {
        return Item::ItemType::Weapon;
    } else if (t == "Map") {
        return Item::ItemType::Map;
    }
}



void Server::itemInfoGetter(Item* item, int type_of_change)
{
    qDebug() << "033[31mЭлемент получен! ;3 /увольте меня из сетевиков/033[0m";
    QByteArray xmlitemData = serializeItemToXML(item, type_of_change);
    qDebug() << "serializetoXML passed (tcpserv.cpp)";
    
    for (QTcpSocket* client_sock : m_clients)
    {
        qDebug() << "в for (tcpserv.cpp)";
        if (client_sock && client_sock->isValid())
        {
            qDebug() << "держи, бро";
            client_sock->write(xmlitemData);
        }
    }


    qDebug() << "с этим всё ок (tcpserv.cpp)";
}



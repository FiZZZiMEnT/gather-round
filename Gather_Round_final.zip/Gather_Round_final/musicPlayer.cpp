#include "musicPlayer.h"

#include <QFile>
#include <QDebug>
#include <QMessageBox>
#include <QDir>


MusicPlayer::MusicPlayer(QWidget *parent)
    : QMediaPlayer(parent) {

    playlist = new QMediaPlaylist;

    QString abs_path = QDir::currentPath(); //Возвращает директорию, где лежит исполняемый
    QDir dir(abs_path+QString::fromUtf8("/music/"));
    if(dir.exists()==false) //Директории не существует
    {
        for(char i =0; i<3; ++i)
        {
            dir.cdUp();
        }

        dir.cd(dir.absolutePath()+QString::fromUtf8("/music/"));
    }

    musicFilepath = dir.absolutePath()+QString::fromUtf8("/");
}


void MusicPlayer::play(QString filePath)
{
    QMediaPlayer::stop();
    playlist->clear();

    QFile file(musicFilepath+filePath);
    if (file.exists()) {
        playlist->addMedia(QUrl::fromLocalFile(musicFilepath+filePath));
        playlist->setPlaybackMode(QMediaPlaylist::Loop);
        setPlaylist(playlist);

        QMediaPlayer::play();
    } else {
        QMessageBox msgBox;
        msgBox.setText(QString::fromUtf8("Композиция ")+filePath+QString::fromUtf8(" не найдена"));
        msgBox.exec();
    }
}

void MusicPlayer::stop()
{
    playlist->clear();
    QMediaPlayer::stop();
}

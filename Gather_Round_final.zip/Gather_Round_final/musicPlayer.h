#ifndef MUSICPLAYER_H
#define MUSICPLAYER_H

#include <QString>
#include <QMediaPlayer>
#include <QMediaPlaylist>

class MusicPlayer: QMediaPlayer
{
    Q_OBJECT;
public:
    MusicPlayer(QWidget *parent = nullptr);
    ~MusicPlayer()=default;

    void play(QString filepath);
    void stop();

private:
    QMediaPlaylist* playlist;

    QString musicFilepath; //Путь до директории с музыкой
};

#endif // MUSICPLAYER_H

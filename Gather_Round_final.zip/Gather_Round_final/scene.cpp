#include "scene.h"

#include <QGraphicsSceneMouseEvent>
#include <cmath>
#include <iostream>

Scene::Scene(QMenu *itemMenu, QObject *parent)
    : QGraphicsScene(parent), currentScale(1), offset_changed(false)
{

    myItemMenu = itemMenu;
    myMode = MoveItem;
    myItemType = Item::Hero;
    myPixmap = QPixmap();
}

void Scene::setMode(Mode mode)
{
    myMode = mode;
}


void Scene::setItemType(Item::ItemType type)
{
    myItemType = type;
}

void Scene::setPixmap(QPixmap pixmap)
{
    myPixmap = pixmap;
}

double& Scene::currScale()
{
    return currentScale;
}

void Scene::mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    if (mouseEvent->button() != Qt::LeftButton) return;

    for (QGraphicsItem *item : items()) {
        item->setSelected(false);
    } // Сняли выделение со всех элементов

    QGraphicsItem* unknownItem;

    QPointF mousePos = mouseEvent->scenePos();
    QPointF newPos = mousePos;

    Item *item;
    action_on_item = 0;
    switch (myMode) { // Оставим switch на случай, если добавятся ещё режимы
    case InsertItem:
        action_on_item = 1;
        item = new Item(myItemType, myPixmap, myItemMenu); //Новая система по вставке элементов
        item_case = qgraphicsitem_cast<Item*>(item); //! так можно ваще?
        addItem(item);

        if(offset_changed==false)
        {
            if(item->type() == Item::Type) offset = QPointF(0,0) - dynamic_cast<Item*>(item)->pos();

                offset_changed = true; // Менять оффсет надо только один раз - сразу же после захвата.
        }
        newPos -= offset;
        newPos.setX(round(newPos.x() / (CELL_SIZE/2)) * CELL_SIZE/2);
        newPos.setY(round(newPos.y() / (CELL_SIZE/2)) * CELL_SIZE/2);
        item->setPos(newPos-offset);
        emit itemInserted(item);
        break;

    case MoveItem:
        action_on_item = 2;
        unknownItem = itemAt(mouseEvent->scenePos(), QTransform());
        item_case = qgraphicsitem_cast<Item*>(unknownItem); 
        qDebug() << "unknownItem(" << unknownItem->type() << ") in scene.cpp:" << unknownItem;
        //qDebug() << "item_case in scene.cpp:" << item;
        if (unknownItem) unknownItem->setSelected(true); // За раз можно выделить только один объект
        break;

    default:
        ;
    }
    QGraphicsScene::mousePressEvent(mouseEvent);
}

void Scene::mouseMoveEvent(QGraphicsSceneMouseEvent *event) {
    QList<QGraphicsItem *> selectedItems = this->selectedItems();
    
    if (!selectedItems.isEmpty()) {
        item_case = qgraphicsitem_cast<Item*>(selectedItems[0]); //! если это хрень - ударьте меня сковородкой

        QPointF mousePos = event->scenePos();

        const qreal gridStep = CELL_SIZE/2;
        QPointF newPos = mousePos;

        // Вычисляем новое положение
        for (QGraphicsItem *item : selectedItems) {
            
            if(offset_changed==false)
            {
                if(item->type() == Item::Type) offset = event->scenePos() - dynamic_cast<Item*>(item)->pos();

                offset_changed = true; // Менять оффсет надо только один раз - сразу же после захвата.
            }
            newPos -= offset;
            newPos.setX(round(newPos.x() / gridStep) * gridStep);
            newPos.setY(round(newPos.y() / gridStep) * gridStep);
            QGraphicsItem::GraphicsItemFlags flags = item->flags();
            //Тащим объект не за центр/левый угол, а за точку, где захватили
            if (flags & QGraphicsItem::ItemIsMovable) item->setPos(newPos);
        }
        event->accept();
    }
}


void Scene::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    offset_changed=false; // Движение закончили - сняли запрет на изменение оффсета
    qDebug() << "mouse release event scene.cpp" << action_on_item;
    emit releaseMouseEventOccurred();
    //!
    if (action_on_item==2){
        action_on_item = 0;
        emit itemInfo(item_case, 2);
    }
    else if (action_on_item==1)
    {
        action_on_item = 0;
        emit itemInfo(item_case, 1);
    }
    //qDebug() << "ReleaseMouseEventOccured";
    QGraphicsScene::mouseReleaseEvent(mouseEvent);
}


void Scene::sandwichSlot(Item *item, int type_of_change)
{
    emit itemInfo(item, type_of_change);
}

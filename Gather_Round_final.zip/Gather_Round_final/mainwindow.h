#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "item.h"
#include "griditem.h"
#include "tcpserv.h"
#include "musicPlayer.h"

#include <QMainWindow>
#include <QVBoxLayout>

class Scene;
QT_BEGIN_NAMESPACE
class QAction;
class QToolBox;
class QButtonGroup;
class QAbstractButton;
class QGraphicsView;
class QComboBox;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:

    // MainWindow(QWidget *parent = nullptr);
    bool loadFile(const QString &); //проверяет, загрузился ли файл
    enum Role { Master, Player };
    explicit MainWindow(Role role, const QString &roomId, QWidget *parent = nullptr);


private slots:
    void buttonGroupClicked(QAbstractButton *button); // Кликаем по кнопке-токену из toolbox`а
    void itemInserted(Item *item);

    //Все действия с удалением/закрепление/деланием невидимым только для сервера
    void deleteItem();
    void pinItem();
    void unpinItem();
    void zoomIn();
    void zoomOut();
    void playMusic();
    void stopMusic();

    //Новые методы с видимостью
    void hideItem();
    void showItem();

    void changePicture();

private:
    void createToolBox();
    void createMenus(); // Создать fileMenu и itemMenu
    void createActions(); // Привязать все QAction к методам
    void createToolbars();
    QWidget *createCellWidget(const QString &text, Item::ItemType type); // Виджет токена в toolbox

    Scene *scene;
    QGraphicsView *view;

    QMenu *fileMenu; // Меню действий с файлом (приложением): закрыть. Потенциал на сохранения состояния карты
    QMenu *itemMenu; // Меню действий с объектом: удалить, закрепить...

    QToolBox *toolBox; // Меню слева

    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction *addAction;
    QAction *deleteAction;
    QAction *pinAction;
    QAction *unpinAction;
    QAction* playMusicAction;
    QAction* stopMusicAction;
    QAction *exitAction;

    //Новые действия с видимостью
    QAction *hideAction;
    QAction *showAction;
    QAction *changeAction;

    QToolBar *editToolBar; // Находится под File, Item в окне приложения
    QToolBar *musicToolBar; // Находится внизу окна. Для работы с музыкой

    QButtonGroup *buttonGroup; // Кнопки-токены из toolbox

    GridItem* grid; // Главная сетка

    MusicPlayer *player; //Проигрыватель музыки
    QComboBox *musicCombo; //Меню выбора трека


    Role currentRole;  // Хранит роль пользователя
    QString roomId;

    //void setupUI(QVBoxLayout *parentLayout);    // Метод для настройки интерфейса в зависимости от роли

signals:
    void musicPlay(QString p);
    void musicStop();
    void pictureChanged(Item* changedItem, int event_ID=1);

};
#endif // MAINWINDOW_H

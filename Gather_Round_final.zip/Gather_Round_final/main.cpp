#include "menuwindow.h"
#include "menuwindow.h"

#include <QApplication>

int main(int argv, char *args[])
{
    Q_INIT_RESOURCE(scene);


    QApplication app(argv, args);
    MenuWindow menuWindow;
    menuWindow.setGeometry(100, 100, 1000, 500);
    menuWindow.show();

    return app.exec();
}


// #include "mainwindow.h"
// #include "menuwindow.h"

// #include <QApplication>
// int main(int argv, char *args[])
// {
//     QApplication app(argv, args);
//     MainWindow mainWindow;
//     mainWindow.setGeometry(100, 100, 1000, 500);
//     mainWindow.show();

//     return app.exec();
// }

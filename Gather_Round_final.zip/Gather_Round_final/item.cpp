#include "item.h"
#include <QDebug>
#include <QGraphicsScene>
#include <QPainter>
#include <QMenu>
#include <QGraphicsSceneContextMenuEvent>
#include <QBitmap>
#include <Qt>

int Item::currID = 0; //статическая переменная для сквозной нумерации
Item::Item(ItemType itemType, QPixmap pixmap, QMenu* ContextMenu,
                         QGraphicsItem *parent)
    : QGraphicsPixmapItem(parent), myItemType(itemType), myContextMenu(ContextMenu), ID(currID++), oldID(-1)
{
    qDebug()<< "  Pixmap:" << pixmap.isNull();

    QPainterPath path;
    int radius = pixmap.width() < pixmap.height()?pixmap.width()/2:pixmap.height()/2;
    if (myItemType != Map)
    {
        qDebug() << "In if  (myItemType != Map) in item.cpp";
        //Обрезаем
        pixmap = pixmap.copy(pixmap.width()/2-radius, pixmap.height()/2-radius, 2*radius, 2*radius);

        QBitmap  mask(pixmap.width(),pixmap.height());
        QPainter painter(&mask);
        mask.fill(Qt::white);
        painter.setBrush(Qt::black);
        painter.drawEllipse(QPoint(pixmap.width()/2, pixmap.height()/2), radius, radius);
        pixmap.setMask(mask);
        
        
    }
    QPainter painter(&pixmap);
    qDebug() << "Activity:" << painter.isActive()<< "  Pixmap:" << pixmap.isNull();
    switch (myItemType) {
    case Monster:
        myColor = Qt::red;
        path.addEllipse(QPointF(0, 0), 100, 100);
        painter.setPen(myColor);
        painter.setBrush(Qt::transparent);
        painter.drawEllipse(QPoint(pixmap.width()/2, pixmap.height()/2), radius, radius);
        myPixmap = pixmap.scaled(CELL_SIZE, CELL_SIZE, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        this->setPixmap(myPixmap);
        myPolygon = path.toFillPolygon();
        break;
    case Hero:
        myColor = Qt::green;
        path.addEllipse(QPointF(0, 0), 100, 100);
        painter.setPen(myColor);
        painter.setBrush(Qt::transparent);
        painter.drawEllipse(QPoint(pixmap.width()/2, pixmap.height()/2), radius, radius);
        myPixmap = pixmap.scaled(CELL_SIZE, CELL_SIZE, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        this->setPixmap(myPixmap);
        myPolygon = path.toFillPolygon();
        break;
    case Map:
        myColor = Qt::black;
        path.addRect(0, 0, 100, 100);
        myPixmap = pixmap;
        this->setPixmap(myPixmap);
        myPolygon = path.toFillPolygon();
        break;
    default:
        qDebug() << "Default switch in item.cpp";
        myColor = Qt::blue;
        path.addEllipse(QPointF(0, 0), 50, 50);
        painter.setPen(myColor);
        painter.setBrush(Qt::transparent);
        painter.drawEllipse(QPoint(pixmap.width()/2, pixmap.height()/2), radius, radius);
        myPixmap = pixmap.scaled(CELL_SIZE/2, CELL_SIZE/2, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        this->setPixmap(myPixmap);
        myPolygon = path.toFillPolygon();
        break;
    }
    if (myItemType == Map)
        setZValue (0.1); //Карта ниже сетки
    else
    {
        setZValue(0.3); //Токен выше сетки и карты
    }
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setFlag(QGraphicsItem::ItemIsSelectable, true);
    setFlag(QGraphicsItem::ItemSendsGeometryChanges, true);
}

QPixmap Item::image() const
{
    QPixmap pixmap(250, 250);
    pixmap.fill(Qt::transparent);
    QPainter painter(&pixmap);
    painter.setPen(QPen(myColor, 8));
    painter.translate(125, 125);
    painter.drawPolyline(myPolygon);
    return pixmap;
}

void Item::contextMenuEvent(QGraphicsSceneContextMenuEvent *event)
{
    scene()->clearSelection();
    setSelected(true);
    myContextMenu->exec(event->screenPos());
}
